require('../lib/readme-gen')().renderFile();
