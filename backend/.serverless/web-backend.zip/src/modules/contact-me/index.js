module.exports = {
    lambda: require('./lambda'),
    saveMessage: require('./save-message'),
    sendEmail: require('./send-email'),
    verifyCaptcha: require('./verify-captcha')
};
